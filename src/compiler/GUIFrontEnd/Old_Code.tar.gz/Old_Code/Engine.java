/** 
 *  This class builds a CLP program to be run symbolically. Firstly,
 *  the Compiler class translates the C program into a CLP
 *  program. Second, several user options are included together with
 *  all libraries required. Finally, the CLP program is run and its
 *  trace is generated and stored in a file which will be further
 *  shown to the user.
 **/

import java.io.*;

public class Engine {
    
    public Engine(){}

    public File runProgram(String program, 
			   String[] options) throws UserOptionError
    {
	/** 
	 * This method runs a program with a set of user options.
	 * @param program the input program to be run.
	 * @param options the vector of user options
	 * @return a file descriptor which contains the traces of the
	 * program.
	 *
	 */

	DataInputStream inFile = null ;
	PrintStream outFile = null;	       
	String enginePath = "src/clpr/";
	File traceFile = null;

	try{
	    // 1. Write to a temp file the C file
	    File temp1 = File.createTempFile("example",".c");	    
	    BufferedWriter out = new BufferedWriter(new FileWriter(temp1));
	    out.write(program);
	    out.close();
 	    // 2. Generate the CLP version of the input C program
 	    inFile = new DataInputStream(new FileInputStream(temp1.getCanonicalPath())) ;
	    File temp2 = File.createTempFile("example",".clp");
 	    outFile = new PrintStream(new FileOutputStream(temp2.getCanonicalPath()));	    
	    // // 2.1 Compile the C input program into CLP program
	    outFile.print("\n /*********************************************/ \n");
	    outFile.print(" /* Generated automatically the CLP(R) program */");
	    outFile.print("\n /*********************************************/ \n");
 	    Compiler.compileOne(inFile,outFile);
	    inFile.close();
	    // // 2.2 Adding user options
	    outFile.print("\n /*********************************************/ \n");
	    outFile.print(" /*     Added automatically user options       */");
	    outFile.print("\n /*********************************************/ \n");
	    traceFile = writeUserOptions(options,outFile);
	    // // 2.3 Including unfolding engine
	    outFile.print("\n /*********************************************/ \n");
	    outFile.print(" /*     Added automatically the engine code    */");
	    outFile.print("\n /*********************************************/ \n");
	    if (options[0].equals("WCET") )
		addCode(enginePath + "wcetmulti.clpr", outFile,"adding wcetmulti.clpr");
	    else{
		if (options[0].equals("SAFETY") )
		    addCode(enginePath + "summ.clpr", outFile,"adding summ.clpr");
		else
		    throw new UserOptionError("Unfold engine" + options[0] + 
					      " not defined\n");
	    }
	    // // 2.4 Including CLP(R) libraries
	    outFile.print("\n /*********************************************/ \n");
	    outFile.print(" /* Added automatically other CLP(R) libraries */");
	    outFile.print("\n /*********************************************/ \n");
	    addCode(enginePath + "tracer.clpr"   , outFile, "adding tracer.clpr");
	    addCode(enginePath + "debug.clpr"    , outFile, "adding debug.clpr");
	    if (options[2].equals("DOT") )
		addCode(enginePath + "dot.clpr", outFile, "adding dot.clpr");
	    else{
		if (options[2].equals("GRAPHML") )
		    addCode(enginePath + "graphML.clpr", outFile, "adding graphML.clpr");
		else{		
		    if (options[2].equals("PAJEK") )
			addCode(enginePath + "pajek.clpr", outFile, "adding pajek.clpr");
		    else
			throw new UserOptionError("Format " + options[2] + " unknown\n");		
		}
	    }
	    outFile.print("\n /*********************************************/ \n");
	    outFile.print(" /*   Added automatically the starting point   */");
	    outFile.print("\n /*********************************************/ \n");	    
	    outFile.print("\n :- main.\n");

	    // Run symbolically the program
	    try{
		Runtime.getRuntime().exec("clpr " + temp2.getCanonicalPath() );						
	    }
	    catch (Exception e){
		System.err.println("An error occurred executing CLP(R)") ;
		e.printStackTrace() ;
		traceFile = null;
	    }     	    
	    outFile.close();
	    // Delete temp file when program exits.
	    temp1.deleteOnExit();
	    temp2.deleteOnExit();	    
	}
	catch (IOException e) {
	    System.err.println("An error occurred compiling program") ;
	    e.printStackTrace() ;
	    traceFile = null;
	} 	
	return traceFile;
    }


    private void addCode(String Program, PrintStream outStream, String ErrorMsg){
	/**
	 * This method add code into an existing program.
	 * @param Program the piece of code to be added
	 * @param outStream the output stream
	 * @param ErrorMsg the error message in case of an exception
	 **/
	try{
	    BufferedReader br = new BufferedReader(new InputStreamReader(
						       new FileInputStream(Program)));
	    String strLine;
	    while ((strLine = br.readLine()) != null) {
		outStream.println(strLine);
	    }
	    br.close();	
	}
	catch (IOException e) {
	    System.err.println("An error occurred " + ErrorMsg) ;
	    e.printStackTrace() ;
	} 	
    }

    private File writeUserOptions(String[] options, 
			 	  PrintStream outFile) throws UserOptionError
    {
	/**
	 * This method writes a set of facts that represent the user
	 * options into a file (the program to be analyzed).
	 * @param  options a vector with the user options.
	 * @param outFile the output stream for the program to be
	 *        analyzed.
	 * @return a file descriptor which will contain the traces.
	 **/  

	File traceFile = null;
	try{	    
	    if (options[1].equals("ON") ){
		if (options[0].equals("WCET"))
			      outFile.print("summarization(y).\n");
		else{
		    if (options[0].equals("SAFETY") )
				  outFile.print("summarization(1).\n");
		    else
			throw new UserOptionError("Unfold engine" + options[0] + 
						  " unknown\n");
		}
	    }
	    else{
		if (options[1].equals("OFF") ){
		    if (options[0].equals("WCET") )
			outFile.print("summarization(n).\n");		    
		    else{
			if (options[0].equals("SAFETY") )						  
			    outFile.print("summarization(0).\n");
			else
			    throw new UserOptionError("Unfold engine " + 
						      options[0] + 						      
						      " unknown\n");
		    }
		}
		else
		    throw new UserOptionError("Summarization option " + 
					      options[1] + 
					      " unknown\n");
	    }
	    if (options[2].equals("DOT") )
		traceFile = File.createTempFile("traces",".dot");	    	    
	    else{
		if (options[2].equals("GRAPHML") )
		    traceFile = File.createTempFile("traces",".graphml");	    
		else{
		    if (options[2].equals("PAJEK") )
			traceFile = File.createTempFile("traces",".net");	    
		    else
			throw new UserOptionError("Format " + options[2] + " unknown\n");		
		}
	    }
	    outFile.print("output_file(\'"  + traceFile.getCanonicalPath() + 
			  "\').\n");	    		 		    
	}
	catch (IOException e) {
	    System.err.println("An error occurred compiling program") ;
	    e.printStackTrace() ;
	} 	
	traceFile.deleteOnExit();
	return traceFile;
    }

    //private String[] fillUserOptions(String[] options) throws UserOptionError
    //{	
    //}


}

