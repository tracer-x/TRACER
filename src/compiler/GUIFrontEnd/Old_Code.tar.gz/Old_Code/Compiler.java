/** 
 *   This class is a wrapper for calling the antlr compiler in order to
 *   translate a C program into a transition system (its CLP version).
 **/   

import java.io.* ;
import antlr.* ;
import antlr.collections.*;
import antlr.TreeParser;
import antlr.debug.misc.* ;

public class Compiler {

    /** This method compiles all C programs located in a directory.
     *  @param examplesDir the input directory
     **/ 

    public static void compileAll(String examplesDir){
	
	DataInputStream dis = null ;
	PrintStream outFile = null;

	File dir = new File(examplesDir);
	FilenameFilter filter = new CFileFilter();

	File[] children = dir.listFiles(filter);
	if (children == null) {
	    System.out.println(dir.getName() + " does NOT exist or is not a directory");
	} else {
	    for (int i=0; i<children.length; i++) {
		// Get filename+extension  of C file 
		String programName = children[i].getAbsolutePath();
		try{
		    dis = new DataInputStream(new FileInputStream(programName)) ;
		}
		catch (FileNotFoundException e){
		    System.err.println("Cant Access file!!") ;
		    e.printStackTrace() ;
		}
		// Get only filename 
		int dotPos = programName.lastIndexOf(".");
		String strExtension = programName.substring(dotPos + 1);
		String strFilename = programName.substring(0, dotPos);
		// Create output clp file
		String outputFileName = strFilename.concat(".clp");
		try{
		    outFile = new PrintStream(new FileOutputStream(outputFileName));		
		}
		catch (FileNotFoundException e){
		    System.err.println("Cant create file!!") ;
		    e.printStackTrace() ;
		}
		
		generateProgram(dis,outFile);

	    }
	}
    }

    /**
     *   This method compiles a C program accessible from an input
     *   stream and writes its CLP version using an output stream.
     *   @param dis the input stream 
     *   @param outFile the output stream
     **/

    public static void compileOne(DataInputStream dis, PrintStream outFile){		
	generateProgram(dis,outFile);	
    }

    private static void generateProgram(DataInputStream dis, PrintStream outFile){

        GnuCLexer lexer = new GnuCLexer(dis) ;
        lexer.setTokenObjectClass("CToken") ;
        lexer.initialize() ;
        GnuCParser parser = new GnuCParser(lexer) ;
        parser.setASTNodeClass(TNode.class.getName()) ;
        TNode.setTokenVocabulary("GNUCTokenTypes") ;
        // invoke parser
        try {
            parser.translationUnit() ;
        } catch ( RecognitionException e ) {
            System.err.println("Fatal IO error:\n" + e) ;
	    e.printStackTrace() ;	    
            System.exit(1) ;
        } catch ( TokenStreamException e ) {
            System.err.println("Fatal IO error:\n" + e) ;
	    e.printStackTrace() ;	    
            System.exit(1) ;
        }
        
        AST ptr = parser.getAST();
	while(ptr != null){
            ASTFrame f = new ASTFrame("Parse Tree", ptr) ;
	    // Uncomment the following to pop up AST windows
	    //            f.setVisible(true) ;
            if(ptr == ptr.getNextSibling()) break;
            else ptr = ptr.getNextSibling();
        }
        
        PrologEmitter e = new PrologEmitter() ;
        e.setASTNodeClass(TNode.class.getName()) ;
	try{
	    e.translationUnit(parser.getAST()) ;
	    e.outputAll(outFile);
	 
	}
	catch (RecognitionException exc){
	    System.err.println("Error getting AST!!") ;
	    exc.printStackTrace() ;	    
	}
    }    
}

class CFileFilter implements FilenameFilter {
    public CFileFilter() {
    }

    public boolean accept(File dir, String s) {
	if (s.endsWith(".c"))
	    return true;
	// others?
	return false;
    }    

}
