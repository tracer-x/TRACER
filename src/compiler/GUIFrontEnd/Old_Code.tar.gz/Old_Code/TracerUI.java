import java.io.*;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import edu.uci.ics.jung.visualization.*;
import edu.uci.ics.jung.graph.*;

public class TracerUI extends javax.swing.JFrame {

    /**
     * Indicates whether a file has been loaded.
     **/
    boolean fileChosen;
    /**
     * Indicates whether a new engine must be generated.
     **/
    boolean obsoleteVersion;

    // Variables declaration 
    private javax.swing.JMenu       jMenuRun;
    private javax.swing.JMenuBar    jMenuBar;
    private javax.swing.JMenu       jMenuFile;
    private javax.swing.JMenuItem   jMenuFileOpen;
    private javax.swing.JMenuItem   jMenuFileQuit;
    private javax.swing.JMenu       jMenuHelp;
    private javax.swing.JMenuItem   jMenuHelpAbout;
    private javax.swing.JMenuItem   jMenuRunAllStepsSum;
    private javax.swing.JMenu       jMenuRunAllSteps;
    private javax.swing.JMenuItem   jMenuRunAllStepsNonSum;
    private javax.swing.JMenuItem   jMenuRunOneStep;
    private javax.swing.JScrollPane jScrollPaneSource;
    private javax.swing.JScrollPane jScrollPaneTree;
    // If JUNG
    //private GraphZoomScrollPane     jScrollPaneTree; 
    private javax.swing.JSplitPane  jSplitPane;
    private javax.swing.JTextArea   jTextAreaSource;
    private javax.swing.JTextArea   jTextAreaTree;
    
    /** Creates new form TracerUI */
    public TracerUI() {
	fileChosen = false;	
	obsoleteVersion = true;
        initComponents();
    }
    
    /**
    * @param args the command line arguments
    */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TracerUI().setVisible(true);
            }
        });
    }

    /** This method is called from within the constructor to
     *  initialize the form.
     */
    private void initComponents() {

        jSplitPane             = new javax.swing.JSplitPane();
        jScrollPaneTree        = new javax.swing.JScrollPane();
	// If JUNG
	// jScrollPaneTree        = null; 
        jTextAreaTree          = new javax.swing.JTextArea();	
	jScrollPaneSource      = new javax.swing.JScrollPane();
        jTextAreaSource        = new javax.swing.JTextArea();
        jMenuBar               = new javax.swing.JMenuBar();
        jMenuFile              = new javax.swing.JMenu();
        jMenuFileOpen          = new javax.swing.JMenuItem();
        jMenuFileQuit          = new javax.swing.JMenuItem();
        jMenuRun               = new javax.swing.JMenu();
        jMenuRunOneStep        = new javax.swing.JMenuItem();
        jMenuRunAllSteps       = new javax.swing.JMenu();
        jMenuRunAllStepsSum    = new javax.swing.JMenuItem();
        jMenuRunAllStepsNonSum = new javax.swing.JMenuItem();
        jMenuHelp              = new javax.swing.JMenu();
        jMenuHelpAbout         = new javax.swing.JMenuItem();


	// TITLE MAIN WINDOW
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("TRACER 1.0");

	//Set up divider location
        jSplitPane.setDividerLocation(400);

	// Set up right side
        jTextAreaTree.setColumns(20);
        jTextAreaTree.setFont(new java.awt.Font("DejaVu Sans", 0, 15));
        jTextAreaTree.setRows(5);

	// if grappa is used
        jScrollPaneTree.setViewportView(jTextAreaTree);
        jSplitPane.setRightComponent(jScrollPaneTree);	

	// Set up left side
        jTextAreaSource.setColumns(20);
        jTextAreaSource.setFont(new java.awt.Font("DejaVu Sans", 0, 15));
        jTextAreaSource.setRows(5);
        jScrollPaneSource.setViewportView(jTextAreaSource);
        jSplitPane.setLeftComponent(jScrollPaneSource);

	// Create Menu

        // FILE
        jMenuFile.setText("File");
        // FILE --> OPEN 
        jMenuFileOpen.setText("Open");
        jMenuFileOpen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuFileOpenActionPerformed(evt);
            }
        });
        jMenuFile.add(jMenuFileOpen);
        // FILE --> QUIT
        jMenuFileQuit.setText("Quit");
        jMenuFileQuit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuFileQuitActionPerformed(evt);
            }
        });
        jMenuFile.add(jMenuFileQuit);
        jMenuBar.add(jMenuFile);

	// RUN
        jMenuRun.setText("Run");

	// RUN --> ONE STEP
        jMenuRunOneStep.setText("One Step");
        jMenuRunOneStep.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuRunOneStepActionPerformed(evt);
            }
        });
        jMenuRun.add(jMenuRunOneStep);

	// RUN --> ALL STEPS
        jMenuRunAllSteps.setText("All Steps");

	// RUN --> ALL STEPS --> SUMMARIZATION
        jMenuRunAllStepsSum.setText("Summarization");
        jMenuRunAllStepsSum.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuRunAllStepsSumActionPerformed(evt);
            }
        });
        jMenuRunAllSteps.add(jMenuRunAllStepsSum);

	// RUN --> ALL STEPS --> NO SUMMARIZATION
        jMenuRunAllStepsNonSum.setText("No summarization");
        jMenuRunAllStepsNonSum.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuRunAllStepsNonSumActionPerformed(evt);
            }
        });
        jMenuRunAllSteps.add(jMenuRunAllStepsNonSum);
        jMenuRun.add(jMenuRunAllSteps);
        jMenuBar.add(jMenuRun);

	// HELP
        jMenuHelp.setText("Help");

	// HELP --> ABOUT
        jMenuHelpAbout.setText("About");
        jMenuHelpAbout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuHelpAboutActionPerformed(evt);
            }
        });
        jMenuHelp.add(jMenuHelpAbout);
        jMenuBar.add(jMenuHelp);
        setJMenuBar(jMenuBar);

	// MAIN WINDOW SIZE is 800x600
        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jSplitPane, javax.swing.GroupLayout.DEFAULT_SIZE, 
			      900, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jSplitPane, javax.swing.GroupLayout.DEFAULT_SIZE, 
			      700, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }

    private void jMenuFileOpenActionPerformed(java.awt.event.ActionEvent evt) {
        JFileChooser jfc = new JFileChooser();
	// Set the current directory
	File f = null;
	try {
	    f = new File(new File("examples").getCanonicalPath());	    
	    jfc.setCurrentDirectory(f);
	} catch (IOException e) {
	    System.err.println("Setting the current directory ..." + e);
	    e.printStackTrace() ;	    
	}
	if (f == null){
	    try{
		f = new File(new File(".").getCanonicalPath());	    
		jfc.setCurrentDirectory(f);
	    }
	    catch (IOException e) {
		System.err.println("Setting the current directory ..." + e);
		e.printStackTrace() ;	    
	    }	   	    
	}
	// Adding a filter
        jfc.addChoosableFileFilter(new CFilter());
        int result = jfc.showOpenDialog(null);
        if ( result == JFileChooser.APPROVE_OPTION ) {
            // Read the file and write it to JTextArea
            try{
                String strLine;
                File selectedFile = jfc.getSelectedFile();
                FileInputStream in = new FileInputStream(selectedFile);
                BufferedReader br = new BufferedReader(new InputStreamReader(in));
		jTextAreaSource.setText(null);
		this.fileChosen = false;
                while ((strLine = br.readLine()) != null) {
                    jTextAreaSource.append(strLine + "\n");
                }
		this.fileChosen = true;
		jTextAreaTree.setText(null);
            }
            catch(Exception e){
                   System.err.println("Opening a file ..." + e);
		   e.printStackTrace() ;
            }
        } else {
            System.err.println("Open file cancelled, or error!");
        }
    }

    private void jMenuFileQuitActionPerformed(java.awt.event.ActionEvent evt) {
        System.exit(0);
    }

    private void jMenuRunOneStepActionPerformed(java.awt.event.ActionEvent evt) {
        String message = "We're sorry, option not available yet\n";
        JOptionPane.showMessageDialog(jSplitPane,message,"Run one step",
                                      JOptionPane.WARNING_MESSAGE);
    }

    private void jMenuRunAllStepsSumActionPerformed(java.awt.event.ActionEvent evt) {
	jMenuRunAllSteps(evt, true);
    }
    
    private void jMenuRunAllStepsNonSumActionPerformed(java.awt.event.ActionEvent evt) {
	jMenuRunAllSteps(evt, false);
    }

    private void jMenuHelpAboutActionPerformed(java.awt.event.ActionEvent evt) {
        String message = "TRACER 1.0 \n" +
                         "National University of Singapore \n" +
                         "(C)2008-2009 \n";
        JOptionPane.showMessageDialog(jSplitPane,message,"About",
                                      JOptionPane.PLAIN_MESSAGE);
    }

    private void jMenuRunAllSteps(java.awt.event.ActionEvent evt, boolean Flag) {
	if (fileChosen){
	    String program = jTextAreaSource.getText();
	    /* BEGIN USER OPTIONS */
	    String[] options;
	    options = new String[3];
	    // this option should be customizable from the GUI
	    options[0] = "WCET";
	    // Flag should be used through options[]
	    if (Flag)
		options[1] = "ON";
	    else
		options[1] = "OFF";	    
	    // Here the file format:
	    options[2] = "DOT";
	    // options[2] = "GRAPHML";
	    // options[2] = "PAJEK";
	    /* END USER OPTIONS */
	    // Dump execution traces on the right panel	    
	    File traceFile = null;
	    try{
		traceFile = new Engine().runProgram(program,options);
		if (traceFile != null){		    
  		    try{
  			// ** Using grappa (Graphviz)
			// - Dot
 			new GrappaUI().showGraph(traceFile.getCanonicalPath(), jScrollPaneTree);	    	
			// ** Using JUNG
			// JungUI jungUI         = new JungUI();
			// - GraphML
			// JungGraphMLFormat j = new JungGraphMLFormat();
			// - Pajek
			// JungPajekFormat j = new JungPajekFormat();
			// Graph g               = j.getGraph(traceFile.getCanonicalPath());
			// VisualizationViewer vv = jungUI.drawGraph(g);			
			// jScrollPaneTree = new GraphZoomScrollPane(vv);
			// jSplitPane.setRightComponent(jScrollPaneTree);
  		    }
  		    catch (IOException e){
  			System.err.println("Problems generating execution tree") ;
  			e.printStackTrace() ;
  		    }
		}
		else{
		    jTextAreaTree.setText("Execution tree could not be generated\n");		
		}
	    }
	    catch (UserOptionError e){
		System.err.println("An error occurred reading user options") ;
		e.printStackTrace() ;
	    }
	}
	else{
	    String message = "You need to select a file \n";
	    JOptionPane.showMessageDialog(jSplitPane,message,"Run program",
					  JOptionPane.WARNING_MESSAGE);
	}	
    }
}

class CFilter extends javax.swing.filechooser.FileFilter {
    public boolean accept(File file) {
	String filename = file.getName();
	return (file.isDirectory() || filename.endsWith(".c"));
    }
    public String getDescription() {
	return "*.c";
    }
}


